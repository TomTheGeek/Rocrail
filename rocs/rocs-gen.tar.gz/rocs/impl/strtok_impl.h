/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 22 2010 19:49:45)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Sep 24 12:13:16 2010
  */

#include "rocs/public/strtok.h"


static const char* name = "OStrTok";

typedef struct OStrTokData {

    /** String value. */
  char* str;
    /** Separator. */
  char sep;
    /** Number of tokens in this string. */
  int countTokens;
    /** Pointer to next token. */
  char* nextToken;

} *iOStrTokData;

static iOStrTokData Data( void* p ) { return (iOStrTokData)((iOStrTok)p)->base.data; }

