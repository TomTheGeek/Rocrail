/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 26 2009 06:34:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Jun 28 08:46:38 2010
  */

#include "rocs/public/strtok.h"


static const char* name = "OStrTok";

typedef struct OStrTokData {

    /** String value. */
  char* str;
    /** Separator. */
  char sep;
    /** Number of tokens in this string. */
  int countTokens;
    /** Pointer to next token. */
  char* nextToken;

} *iOStrTokData;

static iOStrTokData Data( void* p ) { return (iOStrTokData)((iOStrTok)p)->base.data; }

