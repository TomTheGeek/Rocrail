/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 25 2013 08:21:30)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Jan 25 08:27:50 2013
  */

#include "rocs/public/system.h"

/* rocs and system includes: */
#include "rocs/public/thread.h"

static const char* name = "OSystem";

typedef struct OSystemData {

    /**  */
  char WSName[64];
    /**  */
  char UserName[64];
    /**  */
  iOThread ticker;
    /**  */
  unsigned long tick;

} *iOSystemData;

static iOSystemData Data( void* p ) { return (iOSystemData)((iOSystem)p)->base.data; }

