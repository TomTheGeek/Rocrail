/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 25 2011 10:40:36)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Sep 28 17:20:20 2011
  */

#include "rocs/public/system.h"

/* rocs and system includes: */
#include "rocs/public/thread.h"

static const char* name = "OSystem";

typedef struct OSystemData {

    /**  */
  char WSName[64];
    /**  */
  char UserName[64];
    /**  */
  iOThread ticker;
    /**  */
  unsigned long tick;

} *iOSystemData;

static iOSystemData Data( void* p ) { return (iOSystemData)((iOSystem)p)->base.data; }

