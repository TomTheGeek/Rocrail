/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar 30 2011 17:01:46)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Mar 31 17:23:48 2011
  */

#include "rocs/public/ebcdic.h"


static const char* name = "OEbcdic";

typedef struct OEbcdicData {

    /** Active codepage. */
  int CodePage;
    /** External converter file in XML format. */
  const char* file;
    /**  */
  unsigned char AsciiToEbcdicTable[256];
    /**  */
  unsigned char EbcdicToAsciiTable[256];

} *iOEbcdicData;

static iOEbcdicData Data( void* p ) { return (iOEbcdicData)((iOEbcdic)p)->base.data; }

