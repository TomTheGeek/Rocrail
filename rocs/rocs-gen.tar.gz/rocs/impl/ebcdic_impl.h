/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar  3 2010 20:37:20)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Mar  5 07:43:30 2010
  */

#include "rocs/public/ebcdic.h"


static const char* name = "OEbcdic";

typedef struct OEbcdicData {

    /** Active codepage. */
  int CodePage;
    /** External converter file in XML format. */
  const char* file;
    /**  */
  unsigned char AsciiToEbcdicTable[256];
    /**  */
  unsigned char EbcdicToAsciiTable[256];

} *iOEbcdicData;

static iOEbcdicData Data( void* p ) { return (iOEbcdicData)((iOEbcdic)p)->base.data; }

