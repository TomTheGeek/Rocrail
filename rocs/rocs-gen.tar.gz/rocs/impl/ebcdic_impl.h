/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build May 26 2013 22:24:59)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed May 29 12:30:25 2013
  */

#include "rocs/public/ebcdic.h"


static const char* name = "OEbcdic";

typedef struct OEbcdicData {

    /** Active codepage. */
  int CodePage;
    /** External converter file in XML format. */
  const char* file;
    /**  */
  unsigned char AsciiToEbcdicTable[256];
    /**  */
  unsigned char EbcdicToAsciiTable[256];

} *iOEbcdicData;

static iOEbcdicData Data( void* p ) { return (iOEbcdicData)((iOEbcdic)p)->base.data; }

