/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Aug 13 2011 15:44:01)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Aug 18 16:49:07 2011
  */

#include "rocs/public/ebcdic.h"


static const char* name = "OEbcdic";

typedef struct OEbcdicData {

    /** Active codepage. */
  int CodePage;
    /** External converter file in XML format. */
  const char* file;
    /**  */
  unsigned char AsciiToEbcdicTable[256];
    /**  */
  unsigned char EbcdicToAsciiTable[256];

} *iOEbcdicData;

static iOEbcdicData Data( void* p ) { return (iOEbcdicData)((iOEbcdic)p)->base.data; }

