/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Feb 14 2014 11:20:28)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Feb 14 12:59:57 2014
  */

#include "rocs/public/usb.h"


static const char* name = "OUSB";

typedef struct OUSBData {

    /**  */
  void* husb;
    /**  */
  int interfaceNr;
    /**  */
  int input_ep;
    /**  */
  int output_ep;

} *iOUSBData;

static iOUSBData Data( void* p ) { return (iOUSBData)((iOUSB)p)->base.data; }

