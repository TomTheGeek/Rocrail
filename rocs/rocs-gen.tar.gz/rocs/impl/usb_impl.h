/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 31 2014 08:55:14)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Jan 31 09:02:47 2014
  */

#include "rocs/public/usb.h"


static const char* name = "OUSB";

typedef struct OUSBData {

    /**  */
  void* husb;
    /**  */
  int interfaceNr;

} *iOUSBData;

static iOUSBData Data( void* p ) { return (iOUSBData)((iOUSB)p)->base.data; }

