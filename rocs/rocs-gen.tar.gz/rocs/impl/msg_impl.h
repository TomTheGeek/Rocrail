/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 21 2013 10:13:01)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Jan 21 10:16:49 2013
  */

#include "rocs/public/msg.h"


static const char* name = "OMsg";

typedef struct OMsgData {

    /** Reference to sender. */
  obj sender;
    /** Event type. */
  int event;
    /** time to wait before processing */
  int timer;
    /** Optional cargo. */
  void* usrdata;
    /** Type of cargo. */
  usrdatatype type;

} *iOMsgData;

static iOMsgData Data( void* p ) { return (iOMsgData)((iOMsg)p)->base.data; }

