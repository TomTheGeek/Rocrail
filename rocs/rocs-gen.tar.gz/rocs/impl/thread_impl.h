/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Apr 18 2012 17:24:43)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Apr 18 17:25:57 2012
  */

#include "rocs/public/thread.h"


static const char* name = "OThread";

typedef struct OThreadData {

    /** Run method. */
  thread_run run;
    /** Thread name. */
  char* tname;
    /** Thread id. */
  unsigned long id;
    /** Thread handle. */
  unsigned long handle;
    /** Quit is signaled. */
  Boolean quit;
    /** Queue for posting. */
  iOQueue queue;
    /** Thread parameters. */
  void* parm;
    /** Thread stacksize. */
  long stacksize;
    /** Thread description. */
  char* tdesc;
    /** pause is signaled. */
  Boolean pause;

} *iOThreadData;

static iOThreadData Data( void* p ) { return (iOThreadData)((iOThread)p)->base.data; }

