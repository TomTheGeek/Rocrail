/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 31 2014 08:55:14)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Jan 31 09:02:47 2014
  */

#include "rocs/public/event.h"


static const char* name = "OEvent";

typedef struct OEventData {

    /** Event name. */
  char* name;
    /** Event handle. */
  void* handle;
    /**  */
  Boolean posted;

} *iOEventData;

static iOEventData Data( void* p ) { return (iOEventData)((iOEvent)p)->base.data; }

