/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar  7 2010 11:43:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Mar 12 10:12:59 2010
  */

#include "rocs/public/event.h"


static const char* name = "OEvent";

typedef struct OEventData {

    /** Event name. */
  char* name;
    /** Event handle. */
  void* handle;
    /**  */
  Boolean posted;

} *iOEventData;

static iOEventData Data( void* p ) { return (iOEventData)((iOEvent)p)->base.data; }

