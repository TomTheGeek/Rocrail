/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 25 2011 10:40:36)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Sep 28 17:20:20 2011
  */

#include "rocs/public/event.h"


static const char* name = "OEvent";

typedef struct OEventData {

    /** Event name. */
  char* name;
    /** Event handle. */
  void* handle;
    /**  */
  Boolean posted;

} *iOEventData;

static iOEventData Data( void* p ) { return (iOEventData)((iOEvent)p)->base.data; }

