/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 21 2013 10:13:01)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Jan 21 10:16:49 2013
  */

#include "rocs/public/res.h"


static const char* name = "ORes";

typedef struct OResData {

    /** Message values mapped with their key. */
  iOMap msgMap;
    /**  */
  const char* xmlStr;
    /**  */
  const char* language;
    /**  */
  iONode msgNode;

} *iOResData;

static iOResData Data( void* p ) { return (iOResData)((iORes)p)->base.data; }

