/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Feb 16 2010 20:27:31)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Feb 20 11:43:30 2010
  */

#include "rocs/public/str.h"


static const char* name = "OStr";

