/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jun 11 2009 07:08:17)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Trace
  * Date: Thu Jun 11 07:13:20 2009
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/trace_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOTraceData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OTrace ----- */


/** Trace a binary buffer. */
static void _dmp( const void* cargo ,tracelevel level ,int id ,const char* buffer ,int size ) {
  return;
}


/** Trace a binary buffer. */
static void _dump( const void* cargo ,tracelevel level ,const char* buffer ,int size ) {
  return;
}


/** Get's the trace object. */
static struct OTrace* _get( void ) {
  return 0;
}


/** Get the current trace filename. */
static const char* _getCurrentFilename( struct OTrace* inst ) {
  return 0;
}


/** Get trace dumpsize. */
static int _getDumpsize( struct OTrace* inst ) {
  return 0;
}


/** Get the current trace FILE object. */
static const FILE* _getF( struct OTrace* inst ) {
  return 0;
}


/** Get the trace filename. */
static const char* _getFilename( struct OTrace* inst ) {
  return 0;
}


/** Get the trace level(s). */
static tracelevel _getLevel( struct OTrace* inst ) {
  return 0;
}


/** Get the current operating system. */
static const char* _getOS( void ) {
  return 0;
}


/** Object creator. */
static struct OTrace* _inst( tracelevel level ,const char* filename ,Boolean toStdErr ) {
  iOTrace __Trace = allocMem( sizeof( struct OTrace ) );
  iOTraceData data = allocMem( sizeof( struct OTraceData ) );
  MemOp.basecpy( __Trace, &TraceOp, 0, sizeof( struct OTrace ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Trace;
}


/** Get trace to stderr. */
static Boolean _isStdErr( struct OTrace* inst ) {
  return 0;
}


/** Prints the trace header. */
static void _printHeader( void ) {
  return;
}


/** Prints one line into the trace. */
static void _println( const char* fmt ,...  ) {
  return;
}


/** Replace or set the singleton with this one. */
static void _set( struct OTrace* inst ) {
  return;
}


/** Sets the application id to use in the trace. */
static void _setAppID( struct OTrace* inst ,const char* id ) {
  return;
}


/** Set trace dumpsize. */
static void _setDumpsize( struct OTrace* inst ,int size ) {
  return;
}


/** Dump also an ebcdic column. */
static void _setEbcdicDump( struct OTrace* inst ,Boolean ebcdic ) {
  return;
}


/** If set, exceptions are also traced in a separate file. */
static void _setExceptionFile( struct OTrace* inst ,Boolean useexceptionfile ) {
  return;
}


/** Set an exceptionlistener. */
static void _setExceptionListener( struct OTrace* inst ,ExceptionListener listener ,Boolean timestamp ) {
  return;
}


/** Change the trace max. filesize. */
static void _setFileSize( struct OTrace* inst ,int size ) {
  return;
}


/** Change the trace filename. */
static void _setFilename( struct OTrace* inst ,const char* filename ) {
  return;
}


/** Command to invoke when writing a new exception file. */
static void _setInvoke( struct OTrace* inst ,const char* cmd ,Boolean async ) {
  return;
}


/** Change the trace level(s). */
static void _setLevel( struct OTrace* inst ,tracelevel level ) {
  return;
}


/** Set the thread id for main. */
static void _setMainThreadId( unsigned long id ) {
  return;
}


/** Change the number of files before recycling the oldest. */
static void _setNrFiles( struct OTrace* inst ,int cnt ) {
  return;
}


/** Set trace to stderr. */
static void _setStdErr( struct OTrace* inst ,Boolean tostderr ) {
  return;
}


/** Trace. */
static void _terrno( const char* objectname ,tracelevel level ,int line ,int id ,int error ,const char* fmt ,...  ) {
  return;
}


/** Trace. */
static void _trace( const void* cargo ,tracelevel level ,int id ,const char* fmt ,...  ) {
  return;
}


/** Trace. */
static void _trc( const char* objectname ,tracelevel level ,int line ,int id ,const char* fmt ,...  ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/trace.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
