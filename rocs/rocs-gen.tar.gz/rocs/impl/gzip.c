/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Nov 19 2013 14:41:19)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: GZip
  * Date: Tue Nov 19 14:53:54 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/gzip_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOGZipData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OGZip ----- */


/**  */
static Boolean _compress( struct OGZip* inst ) {
  return 0;
}


/**  */
static Boolean _deCompress( struct OGZip* inst ) {
  return 0;
}


/**  */
static int _getRc( struct OGZip* inst ) {
  return 0;
}


/** Object creator. */
static struct OGZip* _inst( const char* fileName ) {
  iOGZip __GZip = allocMem( sizeof( struct OGZip ) );
  iOGZipData data = allocMem( sizeof( struct OGZipData ) );
  MemOp.basecpy( __GZip, &GZipOp, 0, sizeof( struct OGZip ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __GZip;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/gzip.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
