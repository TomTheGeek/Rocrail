/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Dec 24 2009 16:25:24)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Dec 25 22:06:04 2009
  */

#include "rocs/public/file.h"


static const char* name = "OFile";

typedef struct OFileData {

    /** File handle. */
  FILE* fh;
    /**  */
  int openflag;
    /**  */
  char* path;
    /**  */
  long size;
    /**  */
  long readed;
    /**  */
  long written;
    /**  */
  int rc;

} *iOFileData;

static iOFileData Data( void* p ) { return (iOFileData)((iOFile)p)->base.data; }

