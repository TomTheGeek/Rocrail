/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 22 2010 19:49:45)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Sep 24 12:13:16 2010
  */

#include "rocs/public/file.h"


static const char* name = "OFile";

typedef struct OFileData {

    /** File handle. */
  FILE* fh;
    /**  */
  int openflag;
    /**  */
  char* path;
    /**  */
  long size;
    /**  */
  long readed;
    /**  */
  long written;
    /**  */
  int rc;

} *iOFileData;

static iOFileData Data( void* p ) { return (iOFileData)((iOFile)p)->base.data; }

