/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 21 2013 10:13:01)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Jan 21 10:16:49 2013
  */

#include "rocs/public/file.h"


static const char* name = "OFile";

typedef struct OFileData {

    /** File handle. */
  FILE* fh;
    /**  */
  int openflag;
    /**  */
  char* path;
    /**  */
  long size;
    /**  */
  long readed;
    /**  */
  long written;
    /**  */
  int rc;

} *iOFileData;

static iOFileData Data( void* p ) { return (iOFileData)((iOFile)p)->base.data; }

