/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Aug 22 2014 09:00:39)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Aug 23 16:21:31 2014
  */

#include "rocs/public/gzip.h"


static const char* name = "OGZip";

typedef struct OGZipData {

    /**  */
  char* name;
    /**  */
  int rc;

} *iOGZipData;

static iOGZipData Data( void* p ) { return (iOGZipData)((iOGZip)p)->base.data; }

