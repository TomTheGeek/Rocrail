/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 16 2014 07:43:01)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Jan 16 07:46:10 2014
  */

#include "rocs/public/gzip.h"


static const char* name = "OGZip";

typedef struct OGZipData {

    /**  */
  char* name;
    /**  */
  int rc;

} *iOGZipData;

static iOGZipData Data( void* p ) { return (iOGZipData)((iOGZip)p)->base.data; }

