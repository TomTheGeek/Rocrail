/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build May 22 2012 17:41:45)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Tue May 22 18:10:45 2012
  */

#include "rocs/public/gzip.h"


static const char* name = "OGZip";

typedef struct OGZipData {

    /**  */
  char* name;
    /**  */
  int rc;

} *iOGZipData;

static iOGZipData Data( void* p ) { return (iOGZipData)((iOGZip)p)->base.data; }

