/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Apr 18 2012 17:24:43)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Apr 18 17:25:57 2012
  */

#include "rocs/public/mime64.h"


static const char* name = "OMime64";

