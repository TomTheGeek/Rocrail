/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 15 2009 22:28:12)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Jan 16 07:53:17 2009
  */

#include "rocs/public/mime64.h"


static const char* name = "OMime64";

