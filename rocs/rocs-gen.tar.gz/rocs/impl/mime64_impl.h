/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Oct 17 2009 16:29:24)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Oct 17 16:35:20 2009
  */

#include "rocs/public/mime64.h"


static const char* name = "OMime64";

