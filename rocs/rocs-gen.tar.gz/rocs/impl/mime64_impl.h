/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar  5 2010 07:43:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Mar  7 09:50:22 2010
  */

#include "rocs/public/mime64.h"


static const char* name = "OMime64";

