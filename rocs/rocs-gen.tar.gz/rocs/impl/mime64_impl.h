/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 11 2010 12:17:51)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sat Sep 11 12:45:48 2010
  */

#include "rocs/public/mime64.h"


static const char* name = "OMime64";

