/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Oct  8 2009 16:33:18)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Oct  8 16:43:38 2009
  */

#include "rocs/public/mime64.h"


static const char* name = "OMime64";

