/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Nov  6 2009 08:46:35)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Nov  6 08:57:04 2009
  */

#include "rocs/public/attr.h"


static const char* name = "OAttr";

typedef struct OAttrData {

    /** Attribute name. */
  char* name;
    /** Attribute value. */
  char* val;
    /** Attribute value.(Un-escaped.) */
  char* origval;
    /** Attribute is escaped. */
  Boolean escaped;

} *iOAttrData;

static iOAttrData Data( void* p ) { return (iOAttrData)((iOAttr)p)->base.data; }

