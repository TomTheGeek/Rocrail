/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build May  9 2010 11:17:43)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun May  9 11:39:54 2010
  */

#include "rocs/public/attr.h"


static const char* name = "OAttr";

typedef struct OAttrData {

    /** Attribute name. */
  char* name;
    /** Attribute value. */
  char* val;
    /** Attribute value.(Un-escaped.) */
  char* origval;
    /** Attribute is escaped. */
  Boolean escaped;

} *iOAttrData;

static iOAttrData Data( void* p ) { return (iOAttrData)((iOAttr)p)->base.data; }

