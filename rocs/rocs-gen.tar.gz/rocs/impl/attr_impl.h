/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 21 2013 10:13:01)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Jan 21 10:16:49 2013
  */

#include "rocs/public/attr.h"


static const char* name = "OAttr";

typedef struct OAttrData {

    /** Attribute name. */
  char* name;
    /** Attribute value. */
  char* val;
    /** Attribute value.(Un-escaped.) */
  char* origval;
    /** Attribute is escaped. */
  Boolean escaped;

} *iOAttrData;

static iOAttrData Data( void* p ) { return (iOAttrData)((iOAttr)p)->base.data; }

