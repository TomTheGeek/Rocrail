/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Nov 20 2013 16:59:13)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Nov 20 20:10:57 2013
  */

#include "rocs/public/doc.h"


static const char* name = "ODoc";

/*  */
#define startToken "<%s"
/*  */
#define endToken "</%s>"
/*  */
#define endInline "/>"
/*  */
#define remToken "<!--"
/*  */
#define remEndToken "-->"
/*  */
#define propToken "<?"
/*  */
#define propEndToken "?>"
/*  */
#define varToken "<!"
/*  */
#define varEndToken ">"
typedef struct ODocData {

    /** Document. */
  iONode doc;
    /** Root. */
  iONode root;
    /** Is UTF-8 encoded. */
  Boolean utf8;

} *iODocData;

static iODocData Data( void* p ) { return (iODocData)((iODoc)p)->base.data; }

