/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Oct 15 2010 12:39:44)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Oct 15 12:44:15 2010
  */

#include "rocs/public/mutex.h"


static const char* name = "OMutex";

typedef struct OMutexData {

    /** Mutex name. */
  char* name;
    /** Mutex handle. */
  void* handle;
    /**  */
  void* mh;
    /**  */
  int rc;

} *iOMutexData;

static iOMutexData Data( void* p ) { return (iOMutexData)((iOMutex)p)->base.data; }

