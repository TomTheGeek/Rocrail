/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 17 2009 17:26:11)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Sep 17 17:28:56 2009
  */

#include "rocs/public/js.h"


static const char* name = "OJS";

typedef struct OJSData {

    /** file descriptors */
  int jsfd[4];
    /** Listeners list. */
  iOList listeners[4];
    /** HID reader */
  iOThread reader;
    /**  */
  Boolean run;
    /**  */
  int devcnt;

} *iOJSData;

static iOJSData Data( void* p ) { return (iOJSData)((iOJS)p)->base.data; }

