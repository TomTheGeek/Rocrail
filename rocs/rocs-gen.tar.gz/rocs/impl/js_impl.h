/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Nov  6 2009 08:46:35)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Nov  6 08:57:04 2009
  */

#include "rocs/public/js.h"


static const char* name = "OJS";

typedef struct OJSData {

    /** file descriptors */
  int jsfd[4];
    /** Listeners list. */
  iOList listeners[4];
    /** HID reader */
  iOThread reader;
    /**  */
  Boolean run;
    /**  */
  int devcnt;

} *iOJSData;

static iOJSData Data( void* p ) { return (iOJSData)((iOJS)p)->base.data; }

