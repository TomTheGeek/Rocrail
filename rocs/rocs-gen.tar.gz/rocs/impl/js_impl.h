/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 31 2014 08:55:14)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Jan 31 09:02:47 2014
  */

#include "rocs/public/js.h"


static const char* name = "OJS";

typedef struct OJSData {

    /** file descriptors */
  int jsfd[4];
    /** Listeners list. */
  iOList listeners[4];
    /** HID reader */
  iOThread reader;
    /**  */
  Boolean run;
    /**  */
  int devcnt;

} *iOJSData;

static iOJSData Data( void* p ) { return (iOJSData)((iOJS)p)->base.data; }

