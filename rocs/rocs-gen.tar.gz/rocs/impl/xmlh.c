/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Sep 26 2009 06:34:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Xmlh
  * Date: Fri May  6 12:42:44 2011
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/xmlh_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOXmlhData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OXmlh ----- */


/** Add. */
static void _addNode( struct OXmlh* inst ,iONode node ) {
  return;
}


/** Get filename for bin block by index. */
static const char* _getBinName( struct OXmlh* inst ,int idx ) {
  return 0;
}


/** Get size of bin block by index. */
static long _getBinSize( struct OXmlh* inst ,int dataIdx ) {
  return 0;
}


/** Get header childnode by name. */
static iONode _getNodeByTagName( struct OXmlh* inst ,const char* name ,int idx ) {
  return 0;
}


/** Get size of block by name. */
static int _getSizeByTagName( struct OXmlh* inst ,const char* name ,int idx ) {
  return 0;
}


/** Get node for xml block by index. */
static const char* _getXmlName( struct OXmlh* inst ,int dataIdx ) {
  return 0;
}


/** Get size of xml block by index. */
static int _getXmlSize( struct OXmlh* inst ,int idx ) {
  return 0;
}


/** Get number of bin nodes. */
static int _hasBin( struct OXmlh* inst ) {
  return 0;
}


/** Get number of xml nodes. */
static int _hasXml( struct OXmlh* inst ) {
  return 0;
}


/** Object creator. */
static struct OXmlh* _inst( Boolean create ,const char* header_tagname ,const char* bin_tagname ) {
  iOXmlh __Xmlh = allocMem( sizeof( struct OXmlh ) );
  iOXmlhData data = allocMem( sizeof( struct OXmlhData ) );
  MemOp.basecpy( __Xmlh, &XmlhOp, 0, sizeof( struct OXmlh ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Xmlh;
}


/** Get error state of Xmlh. */
static Boolean _isError( struct OXmlh* inst ) {
  return 0;
}


/** Reads the Xmlh from buffer. True if complete header is read. */
static Boolean _read( struct OXmlh* inst ,const byte* buffer ,int size ) {
  return 0;
}


/**  */
static void _reset( struct OXmlh* inst ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/xmlh.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
