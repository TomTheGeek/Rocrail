/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jan 18 2011 17:59:59)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Mutex
  * Date: Tue Jan 18 18:08:33 2011
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/mutex_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOMutexData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OMutex ----- */


/** Get last error code. */
static int _getRc( struct OMutex* inst ) {
  return 0;
}


/** Object creator */
static struct OMutex* _inst( const char* name ,Boolean create ) {
  iOMutex __Mutex = allocMem( sizeof( struct OMutex ) );
  iOMutexData data = allocMem( sizeof( struct OMutexData ) );
  MemOp.basecpy( __Mutex, &MutexOp, 0, sizeof( struct OMutex ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Mutex;
}


/** Release the mutext. (release, unlock) */
static Boolean _post( struct OMutex* inst ) {
  return 0;
}


/** Wait for the mutext. */
static Boolean _trywait( struct OMutex* inst ,int time ) {
  return 0;
}


/** Wait for the mutext. (request, lock) */
static Boolean _wait( struct OMutex* inst ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/mutex.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
