/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Sep 26 2009 06:34:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Serial
  * Date: Fri May  6 12:42:44 2011
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/serial_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOSerialData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OSerial ----- */


/** Get number of bytes available to read. */
static int _available( struct OSerial* inst ) {
  return 0;
}


/** Close the port. */
static Boolean _close( struct OSerial* inst ) {
  return 0;
}


/** clear output buffer */
static void _flush( struct OSerial* inst ) {
  return;
}


/** Get last error. */
static int _getRc( struct OSerial* inst ) {
  return 0;
}


/** Get actual readed byte count. */
static int _getReadCnt( struct OSerial* inst ) {
  return 0;
}


/** Get number of bytes waiting to send. */
static int _getWaiting( struct OSerial* inst ) {
  return 0;
}


/** Object creator. */
static struct OSerial* _inst( const char* device ) {
  iOSerial __Serial = allocMem( sizeof( struct OSerial ) );
  iOSerialData data = allocMem( sizeof( struct OSerialData ) );
  MemOp.basecpy( __Serial, &SerialOp, 0, sizeof( struct OSerial ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Serial;
}


/** Control To Send. */
static Boolean _isCTS( struct OSerial* inst ) {
  return 0;
}


/** Data Set Ready. */
static Boolean _isDSR( struct OSerial* inst ) {
  return 0;
}


/** Ring Indicator. */
static Boolean _isRI( struct OSerial* inst ) {
  return 0;
}


/**  */
static Boolean _isUartEmpty( struct OSerial* inst ,Boolean soft ) {
  return 0;
}


/** Try to open and to initialize the port. */
static Boolean _open( struct OSerial* inst ) {
  return 0;
}


/** Read some bytes. */
static Boolean _read( struct OSerial* inst ,char* buffer ,int count ) {
  return 0;
}


/** Set blocking/non-blocking io. */
static void _setBlocking( struct OSerial* inst ,Boolean blocking ) {
  return;
}


/** Clear To Send. */
static void _setCTS( struct OSerial* inst ,Boolean cts ) {
  return;
}


/** Data Terminal Ready. */
static void _setDTR( struct OSerial* inst ,Boolean dtr ) {
  return;
}


/** Custom Divisor. */
static void _setDivisor( struct OSerial* inst ,int divisor ) {
  return;
}


/** Set data flow control. */
static void _setFlow( struct OSerial* inst ,serial_flow flow ) {
  return;
}


/** Set line settings. */
static void _setLine( struct OSerial* inst ,serial_bps bps ,serial_databits databits ,serial_stopbits stopbits ,serial_parity parity ,Boolean rtsdisabled ) {
  return;
}


/** set output flow on off */
static void _setOutputFlow( struct OSerial* inst ,Boolean flow ) {
  return;
}


/** Set data flow control. */
static void _setPortBase( struct OSerial* inst ,int addr ) {
  return;
}


/** Request To Send. */
static void _setRTS( struct OSerial* inst ,Boolean rts ) {
  return;
}


/** Set uart speed for MM or DCC */
static void _setSerialMode( struct OSerial* inst ,serial_mode mode ) {
  return;
}


/** Set timeout. */
static void _setTimeout( struct OSerial* inst ,int wtime ,int trime ) {
  return;
}


/** Do busy wait for MM protocol */
static void _waitMM( struct OSerial* inst ,int usperiod ,int uspause ) {
  return;
}


/** Write some bytes. */
static Boolean _write( struct OSerial* inst ,const char* buffer ,int count ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/serial.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
