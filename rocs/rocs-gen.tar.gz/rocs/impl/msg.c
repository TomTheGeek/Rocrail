/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Nov 19 2013 14:41:19)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Msg
  * Date: Tue Nov 19 14:53:54 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/msg_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOMsgData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OMsg ----- */


/**  */
static int _getEvent( struct OMsg* inst ) {
  return 0;
}


/**  */
static obj _getSender( struct OMsg* inst ) {
  return 0;
}


/**  */
static int _getTimer( struct OMsg* inst ) {
  return 0;
}


/**  */
static void* _getUsrData( struct OMsg* inst ) {
  return 0;
}


/**  */
static usrdatatype _getUsrDataType( struct OMsg* inst ) {
  return 0;
}


/** Object creator. */
static struct OMsg* _inst( obj sender ,int event ) {
  iOMsg __Msg = allocMem( sizeof( struct OMsg ) );
  iOMsgData data = allocMem( sizeof( struct OMsgData ) );
  MemOp.basecpy( __Msg, &MsgOp, 0, sizeof( struct OMsg ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Msg;
}


/**  */
static void _setEvent( struct OMsg* inst ,int event ) {
  return;
}


/**  */
static void _setTimer( struct OMsg* inst ,int timer ) {
  return;
}


/**  */
static void _setUsrData( struct OMsg* inst ,void* usrdata ,usrdatatype type ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/msg.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
