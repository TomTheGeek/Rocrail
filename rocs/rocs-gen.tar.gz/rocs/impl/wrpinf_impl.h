/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar  3 2010 20:37:20)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Mar  5 07:43:30 2010
  */

#include "rocs/public/wrpinf.h"


static const char* name = "OWrpInf";

typedef struct OWrpInfData {

    /** Wrapper nodes mapped with their name. */
  iOMap wrpMap;
    /** Array of xml string. */
  const char** xmlStrs;
    /**  */
  int cnt;
    /**  */
  iONode wrpNode;

} *iOWrpInfData;

static iOWrpInfData Data( void* p ) { return (iOWrpInfData)((iOWrpInf)p)->base.data; }

