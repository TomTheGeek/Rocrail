/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 21 2013 10:13:01)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Jan 21 10:16:49 2013
  */

#include "rocs/public/wrpinf.h"


static const char* name = "OWrpInf";

typedef struct OWrpInfData {

    /** Wrapper nodes mapped with their name. */
  iOMap wrpMap;
    /** Array of xml string. */
  const char** xmlStrs;
    /**  */
  int cnt;
    /**  */
  iONode wrpNode;

} *iOWrpInfData;

static iOWrpInfData Data( void* p ) { return (iOWrpInfData)((iOWrpInf)p)->base.data; }

