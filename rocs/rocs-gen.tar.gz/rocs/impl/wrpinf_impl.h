/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 15 2009 22:28:12)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Jan 16 07:53:17 2009
  */

#include "rocs/public/wrpinf.h"


static const char* name = "OWrpInf";

typedef struct OWrpInfData {

    /** Wrapper nodes mapped with their name. */
  iOMap wrpMap;
    /** Array of xml string. */
  const char** xmlStrs;
    /**  */
  int cnt;
    /**  */
  iONode wrpNode;

} *iOWrpInfData;

static iOWrpInfData Data( void* p ) { return (iOWrpInfData)((iOWrpInf)p)->base.data; }

