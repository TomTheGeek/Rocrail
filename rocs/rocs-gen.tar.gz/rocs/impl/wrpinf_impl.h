/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build May  9 2010 11:17:43)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun May  9 11:39:54 2010
  */

#include "rocs/public/wrpinf.h"


static const char* name = "OWrpInf";

typedef struct OWrpInfData {

    /** Wrapper nodes mapped with their name. */
  iOMap wrpMap;
    /** Array of xml string. */
  const char** xmlStrs;
    /**  */
  int cnt;
    /**  */
  iONode wrpNode;

} *iOWrpInfData;

static iOWrpInfData Data( void* p ) { return (iOWrpInfData)((iOWrpInf)p)->base.data; }

