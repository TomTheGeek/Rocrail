/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 22 2010 19:49:45)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Sep 24 12:13:16 2010
  */

#include "rocs/public/wrpinf.h"


static const char* name = "OWrpInf";

typedef struct OWrpInfData {

    /** Wrapper nodes mapped with their name. */
  iOMap wrpMap;
    /** Array of xml string. */
  const char** xmlStrs;
    /**  */
  int cnt;
    /**  */
  iONode wrpNode;

} *iOWrpInfData;

static iOWrpInfData Data( void* p ) { return (iOWrpInfData)((iOWrpInf)p)->base.data; }

