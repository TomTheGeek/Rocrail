/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build May 29 2013 12:30:38)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu May 30 08:36:52 2013
  */

#include "rocs/public/cmdln.h"


static const char* name = "OCmdLn";

typedef struct OCmdLnData {

    /** Argument count. */
  int argc;
    /** Argument values. */
  const char** argv;
    /** Argument values mapped with their key. */
  iOMap argMap;
    /**  */
  char* argStr;

} *iOCmdLnData;

static iOCmdLnData Data( void* p ) { return (iOCmdLnData)((iOCmdLn)p)->base.data; }

