/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 26 2009 06:34:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Jun 28 08:46:38 2010
  */

#include "rocs/public/cmdln.h"


static const char* name = "OCmdLn";

typedef struct OCmdLnData {

    /** Argument count. */
  int argc;
    /** Argument values. */
  const char** argv;
    /** Argument values mapped with their key. */
  iOMap argMap;
    /**  */
  char* argStr;

} *iOCmdLnData;

static iOCmdLnData Data( void* p ) { return (iOCmdLnData)((iOCmdLn)p)->base.data; }

