/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 31 2014 08:55:14)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Jan 31 09:02:47 2014
  */

#include "rocs/public/cmdln.h"


static const char* name = "OCmdLn";

typedef struct OCmdLnData {

    /** Argument count. */
  int argc;
    /** Argument values. */
  const char** argv;
    /** Argument values mapped with their key. */
  iOMap argMap;
    /**  */
  char* argStr;

} *iOCmdLnData;

static iOCmdLnData Data( void* p ) { return (iOCmdLnData)((iOCmdLn)p)->base.data; }

