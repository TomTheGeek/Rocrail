/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Nov 19 2013 14:41:19)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: File
  * Date: Tue Nov 19 14:53:54 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/file_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOFileData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OFile ----- */


/** Test for read permission. */
static Boolean _access( const char* filename ) {
  return 0;
}


/** Appends a buffer to the file. */
static Boolean _append( struct OFile* inst ,const char* buffer ,long size ) {
  return 0;
}


/** Change the working directory. */
static Boolean _cd( const char* pathname ) {
  return 0;
}


/** Closes the file. It does not cleanup this object. */
static Boolean _close( struct OFile* inst ) {
  return 0;
}


/** Changes the separators according the OS. */
static void _convertPath2OSType( const char* pathname ) {
  return;
}


/** Copies a file. */
static Boolean _cp( const char* src ,const char* dst ) {
  return 0;
}


/** Checks for file or directory existence. */
static Boolean _exist( const char* name ) {
  return 0;
}


/** Gets the filesize in bytes. */
static long _fileSize( const char* filename ) {
  return 0;
}


/** Gets the modification time for the given file. */
static long _fileTime( const char* filename ) {
  return 0;
}


/** Writes all buffered byte on disk. */
static Boolean _flush( struct OFile* inst ) {
  return 0;
}


/** Writes a formatted string into the file. */
static Boolean _fmt( struct OFile* inst ,const char* fstr ,...  ) {
  return 0;
}


/** Renames a file, target will be removed if the newname already exist. */
static Boolean _forcerename( const char* oldname ,const char* newname ) {
  return 0;
}


/** Gets the filename used by this file object. */
static const char* _getFilename( struct OFile* inst ) {
  return 0;
}


/** Returns a new allocated path string. */
static char* _getPath( const char* path ) {
  return 0;
}


/** Get the latest error. */
static int _getRc( struct OFile* inst ) {
  return 0;
}


/** Gets the count of the readed bytes. */
static long _getReaded( struct OFile* inst ) {
  return 0;
}


/**  */
static FILE* _getStream( struct OFile* inst ) {
  return 0;
}


/** Gets the count of the written bytes. */
static long _getWritten( struct OFile* inst ) {
  return 0;
}


/** Gets the filepointer position. */
static long _getpos( struct OFile* inst ) {
  return 0;
}


/** Object creator. */
static struct OFile* _inst( const char* path ,int openflag ) {
  iOFile __File = allocMem( sizeof( struct OFile ) );
  iOFileData data = allocMem( sizeof( struct OFileData ) );
  MemOp.basecpy( __File, &FileOp, 0, sizeof( struct OFile ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __File;
}


/** Checks if given path is absolute. */
static Boolean _isAbsolute( const char* path ) {
  return 0;
}


/** Checks with fuser if the file is accessed by another process. */
static Boolean _isAccessed( const char* filename ) {
  return 0;
}


/** True if given name points to a directory. */
static Boolean _isDirectory( const char* filename ) {
  return 0;
}


/** False if given name points not to a regular file. */
static Boolean _isRegularFile( const char* filename ) {
  return 0;
}


/** Make directory. */
static Boolean _mkdir( const char* dirname ) {
  return 0;
}


/** The process working directory. */
static char* _pwd( void ) {
  return 0;
}


/** Reads from file; True if successful. */
static Boolean _read( struct OFile* inst ,char* buffer ,long size ) {
  return 0;
}


/** Reads one line from file; True if successful. */
static Boolean _readStr( struct OFile* inst ,char* buffer ) {
  return 0;
}


/** Removes the given file. */
static Boolean _remove( const char* filename ) {
  return 0;
}


/** Renames a file. */
static Boolean _rename( const char* oldname ,const char* newname ) {
  return 0;
}


/** Reopens this file. */
static Boolean _reopen( struct OFile* inst ,Boolean truncate ) {
  return 0;
}


/** Sets the filepointer to the beginning of the file. */
static Boolean _rewind( struct OFile* inst ) {
  return 0;
}


/** Returns a pointer to the filename. */
static const char* _ripPath( const char* filename ) {
  return 0;
}


/** Removes given directory. */
static Boolean _rmdir( const char* path ) {
  return 0;
}


/** Sets the filename to use with this object. */
static void _setFilename( struct OFile* inst ,const char* filename ) {
  return;
}


/** Sets the fuser command to use for isAccessed. */
static void _setFuser( const char* filename ) {
  return;
}


/** The Linux fuser returns a useable rc. With all other unixes we must use a temp file. */
static void _setFuserUsage( const char* usage ) {
  return;
}


/** Sets the modification time for the given file. */
static Boolean _setfileTime( const char* filename ,long filetime ) {
  return 0;
}


/** Sets the filepointer to the given offset. */
static Boolean _setpos( struct OFile* inst ,long offset ) {
  return 0;
}


/** Get the filesize in bytes. */
static long _size( struct OFile* inst ) {
  return 0;
}


/** Write to file; True if successful. */
static Boolean _write( struct OFile* inst ,const char* buffer ,long size ) {
  return 0;
}


/** Appends a string to the file. */
static Boolean _writeStr( struct OFile* inst ,const char* str ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/file.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
