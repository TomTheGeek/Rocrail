/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jun  7 2010 07:50:17)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Mem
  * Date: Mon Jun  7 07:50:45 2010
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/mem_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OMem ----- */


/** Allocate memory and records sourcefile and line. (Use macro allocMem.) */
static void* _alloc( long size ,const char* file ,int line ) {
  return 0;
}


/** Allocate memory and records sourcefile and line. (Use macro allocIDMem.) */
static void* _allocTID( long size ,int id ,const char* file ,int line ) {
  return 0;
}


/** A special copy function for creating rocs-based objects. */
static void _basecpy( void* dst ,void* src ,int asize ,int tsize ,void* data ) {
  return;
}


/** Find a char in memoryblock. */
static char* _chr( const void* buffer ,char c ,int size ) {
  return 0;
}


/** Compairs two memory blocks. */
static Boolean _cmp( const void* dst ,const void* src ,int size ) {
  return 0;
}


/** Copies a memory block. */
static void _copy( void* dst ,const void* src ,int size ) {
  return;
}


/** Dumps allocation count by ID. */
static const long* _dumpAllocCntID( void ) {
  return 0;
}


/** Free up memory and records sourcefile and line. (Use macro freeMem.) */
static void _free( void* p ,const char* file ,int line ) {
  return;
}


/** Free up obj memory. */
static void _freeObj( void** p ) {
  return;
}


/** Free up memory and records sourcefile and line. (Use macro freeIDMem.) */
static void _freeTID( void* p ,int id ,const char* file ,int line ) {
  return;
}


/** Returns allocation count by ID. */
static long _getAllocCntID( int id ) {
  return 0;
}


/** Returns number of allocated memory objects. */
static long _getAllocCount( void ) {
  return 0;
}


/** Returns total allocated memory size. */
static long _getAllocSize( void ) {
  return 0;
}


/**  */
static int _getDumpSize( void ) {
  return 0;
}


/**  */
static const char* _getLastOperation( void ) {
  return 0;
}


/**  */
static void _init( void ) {
  return;
}


/** Re-Allocate memory and records sourcefile and line. (Use macro reallocMem.) */
static void* _realloc( void* p ,long size ,const char* file ,int line ) {
  return 0;
}


/**  */
static void _resetDump( void ) {
  return;
}


/** Initializes a memory block. */
static void _set( void* p ,int val ,int size ) {
  return;
}


/** If set it prints for every allocation and free a line. */
static void _setDebug( Boolean debug ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/mem.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
