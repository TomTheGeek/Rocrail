/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jan 18 2011 17:59:59)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Dir
  * Date: Tue Jan 18 18:08:33 2011
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/dir_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iODirData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- ODir ----- */


/** free all memory allocated by listdir() */
static void _cleandirlist( iOList list ) {
  return;
}


/** Closes the direntry. */
static void _close( struct ODir* inst ) {
  return;
}


/** Get the last error. */
static int _getRc( struct ODir* inst ) {
  return 0;
}


/** Creates a directory object. */
static struct ODir* _inst( const char* path ) {
  iODir __Dir = allocMem( sizeof( struct ODir ) );
  iODirData data = allocMem( sizeof( struct ODirData ) );
  MemOp.basecpy( __Dir, &DirOp, 0, sizeof( struct ODir ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Dir;
}


/** Scans the directory for entries with given ending. */
static iOList _listdir( const char* path ,const char* ext ,sortmode sort ) {
  return 0;
}


/** Opens the directory for reading. */
static Boolean _open( struct ODir* inst ) {
  return 0;
}


/** Reads an direntry. */
static const char* _read( struct ODir* inst ) {
  return 0;
}


/** Scans the directory for entries with given ending. */
static int _scandir( const char* path ,const char* ext ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/dir.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
