/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Nov 19 2013 14:41:19)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: WrpInf
  * Date: Tue Nov 19 14:53:54 2013
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/wrpinf_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOWrpInfData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OWrpInf ----- */


/** Get all var nodes. */
static iOList _getVars( iONode wrp ) {
  return 0;
}


/** Get a wrapper by key. */
static iONode _getWrapper( struct OWrpInf* inst ,const char* wrpname ) {
  return 0;
}


/** Creates a resource object. */
static struct OWrpInf* _inst( const char** xmls ,int cnt ) {
  iOWrpInf __WrpInf = allocMem( sizeof( struct OWrpInf ) );
  iOWrpInfData data = allocMem( sizeof( struct OWrpInfData ) );
  MemOp.basecpy( __WrpInf, &WrpInfOp, 0, sizeof( struct OWrpInf ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __WrpInf;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/wrpinf.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
