/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 17 2009 17:26:11)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Sep 17 17:28:56 2009
  */

#include "rocs/public/queue.h"


static const char* name = "OQueue";


/**  */
typedef struct SqMsg {
    /**  */
  obj o;
    /**  */
  q_prio prio;
    /**  */
  struct SqMsg* next;
} *qMsg;
typedef struct OQueueData {

    /** Queue size. */
  int size;
    /** Number of messages in queue. */
  int count;
    /**  */
  iOMutex mux;
    /**  */
  iOEvent evt;
    /**  */
  qMsg first;
    /** 0 points to the last low prio message, 2 to the high. */
  qMsg last[3];

} *iOQueueData;

static iOQueueData Data( void* p ) { return (iOQueueData)((iOQueue)p)->base.data; }

