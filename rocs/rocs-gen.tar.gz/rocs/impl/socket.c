/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Oct 19 2012 21:09:54)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Socket
  * Date: Mon Oct 22 16:35:58 2012
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/socket_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOSocketData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OSocket ----- */


/** Accept client connections. */
static struct OSocket* _accept( struct OSocket* inst ) {
  return 0;
}


/**  */
static Boolean _bind( struct OSocket* inst ) {
  return 0;
}


/** Connect socket with target. */
static Boolean _connect( struct OSocket* inst ) {
  return 0;
}


/** Disconnect from remote peer. */
static void _disConnect( struct OSocket* inst ) {
  return;
}


/** Formats a string. */
static Boolean _fmt( struct OSocket* inst ,const char* format ,...  ) {
  return 0;
}


/**  */
static char* _getMAC( const char* device ) {
  return 0;
}


/** Get number of peeked bytes. */
static long _getPeeked( struct OSocket* inst ) {
  return 0;
}


/**  */
static const char* _getPeername( struct OSocket* inst ) {
  return 0;
}


/** Get last error. */
static int _getRc( struct OSocket* inst ) {
  return 0;
}


/** Get number of readed bytes. */
static long _getReceived( struct OSocket* inst ) {
  return 0;
}


/** Get number of written bytes. */
static long _getSended( struct OSocket* inst ) {
  return 0;
}


/** Get socket stream object. */
static FILE * _getStream( struct OSocket* inst ) {
  return 0;
}


/** Get local host dotted address. */
static const char* _gethostaddr( void ) {
  return 0;
}


/** Get local hostname. */
static const char* _gethostname( void ) {
  return 0;
}


/** Object creator. */
static struct OSocket* _inst( const char* host ,int port ,Boolean ssl ,Boolean udp ,Boolean multicast ) {
  iOSocket __Socket = allocMem( sizeof( struct OSocket ) );
  iOSocketData data = allocMem( sizeof( struct OSocketData ) );
  MemOp.basecpy( __Socket, &SocketOp, 0, sizeof( struct OSocket ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Socket;
}


/** Object creator. */
static struct OSocket* _instSSLserver( int port ,const char* certFile ,const char* keyFile ) {
  return 0;
}


/** Is connection broken? */
static Boolean _isBroken( struct OSocket* inst ) {
  return 0;
}


/** Socket is connected. */
static Boolean _isConnected( struct OSocket* inst ) {
  return 0;
}


/** OpenSSL support is enabled. */
static Boolean _isOpenSSL( void ) {
  return 0;
}


/** Check if last returncode is a ETIMEDOUT error. */
static Boolean _isTimedOut( struct OSocket* inst ) {
  return 0;
}


/** Are some bytes waiting to be read? */
static Boolean _peek( struct OSocket* inst ,char* buffer ,int size ) {
  return 0;
}


/** Read bytes. */
static Boolean _read( struct OSocket* inst ,char* buffer ,int size ) {
  return 0;
}


/** Read til a terminating zero is detected. */
static char* _readStr( struct OSocket* inst ,char* buffer ) {
  return 0;
}


/** Read one character. */
static char _readc( struct OSocket* inst ) {
  return 0;
}


/** Read till a linefeed is detected. */
static char* _readln( struct OSocket* inst ,char* buffer ) {
  return 0;
}


/** Receive udp message. */
static int _recvfrom( struct OSocket* inst ,char* buffer ,int size ,char* client ,int* port ) {
  return 0;
}


/** Reset the socket; clear flags. */
static void _reset( struct OSocket* inst ) {
  return;
}


/** Send udp message. */
static Boolean _sendto( struct OSocket* inst ,char* buffer ,int size ,char* client ,int port ) {
  return 0;
}


/** Set blocking. */
static Boolean _setBlocking( struct OSocket* inst ,Boolean blocking ) {
  return 0;
}


/**  */
static Boolean _setKeepalive( struct OSocket* inst ,Boolean keepalive ) {
  return 0;
}


/** NOT IMPLEMENTED!. */
static void _setListener( struct OSocket* inst ,socket_listener listener ) {
  return;
}


/** Local interface IP. */
static void _setLocalIP( struct OSocket* inst ,const char* ip ) {
  return;
}


/**  */
static Boolean _setNodelay( struct OSocket* inst ,Boolean flag ) {
  return 0;
}


/** Set timeout value for reading. */
static Boolean _setRcvTimeout( struct OSocket* inst ,int timeout ) {
  return 0;
}


/** Set timeout value for writing. */
static Boolean _setSndTimeout( struct OSocket* inst ,int timeout ) {
  return 0;
}


/** Write bytes. */
static Boolean _write( struct OSocket* inst ,const char* buffer ,int size ) {
  return 0;
}


/** Write one character. */
static Boolean _writec( struct OSocket* inst ,char c ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/socket.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
