/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar 30 2011 17:01:46)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Mar 31 17:23:48 2011
  */

#include "rocs/public/string.h"


static const char* name = "OString";

/*  */
#define STRING_MINSIZE 80
typedef struct OStringData {

    /** String value. */
  char* str;
    /** String length. */
  int len;

} *iOStringData;

static iOStringData Data( void* p ) { return (iOStringData)((iOString)p)->base.data; }

