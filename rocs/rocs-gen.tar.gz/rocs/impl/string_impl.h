/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 12 2009 12:08:40)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Tue Sep 15 18:15:11 2009
  */

#include "rocs/public/string.h"


static const char* name = "OString";

/*  */
#define STRING_MINSIZE 80
typedef struct OStringData {

    /** String value. */
  char* str;
    /** String length. */
  int len;

} *iOStringData;

static iOStringData Data( void* p ) { return (iOStringData)((iOString)p)->base.data; }

