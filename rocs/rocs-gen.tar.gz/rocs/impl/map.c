/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Sep 26 2009 06:34:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Map
  * Date: Tue May 18 07:14:56 2010
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/map_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOMapData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OMap ----- */


/** Clear the map. */
static void _clear( struct OMap* inst ) {
  return;
}


/** Get the first item from the map. */
static obj _first( struct OMap* inst ) {
  return 0;
}


/** Get an item from the map. */
static obj _get( struct OMap* inst ,const char* key ) {
  return 0;
}


/** Get all mapped objects as a list. */
static iOList _getList( struct OMap* inst ) {
  return 0;
}


/** Check if a map entry exist with the given key. */
static Boolean _haskey( struct OMap* inst ,const char* key ) {
  return 0;
}


/** Map object creator. */
static struct OMap* _inst( void ) {
  iOMap __Map = allocMem( sizeof( struct OMap ) );
  iOMapData data = allocMem( sizeof( struct OMapData ) );
  MemOp.basecpy( __Map, &MapOp, 0, sizeof( struct OMap ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Map;
}


/** Get the next item from the map. */
static obj _next( struct OMap* inst ) {
  return 0;
}


/** Put a new item in the map. */
static void _put( struct OMap* inst ,const char* key ,obj val ) {
  return;
}


/** Remove an item from the map. */
static obj _remove( struct OMap* inst ,const char* key ) {
  return 0;
}


/** Get the size of the map. (Number of objects in the map.) */
static int _size( struct OMap* inst ) {
  return 0;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/map.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
