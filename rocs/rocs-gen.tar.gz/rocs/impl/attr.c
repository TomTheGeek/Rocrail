/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Sep 26 2009 06:34:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Attr
  * Date: Fri May  6 12:42:44 2011
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/attr_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOAttrData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OAttr ----- */


/** Attribute value. */
static Boolean _getBoolean( struct OAttr* inst ) {
  return 0;
}


/** Escaped attribute value. */
static const char* _getEscVal( struct OAttr* inst ) {
  return 0;
}


/** Attribute value. */
static double _getFloat( struct OAttr* inst ) {
  return 0;
}


/** Attribute value. */
static int _getInt( struct OAttr* inst ) {
  return 0;
}


/** Attribute value. */
static long _getLong( struct OAttr* inst ) {
  return 0;
}


/** Attribute name. */
static const char* _getName( struct OAttr* inst ) {
  return 0;
}


/** Attribute value. */
static const char* _getVal( struct OAttr* inst ) {
  return 0;
}


/** Creates an attribute with given name and value. */
static struct OAttr* _inst( const char* name ,const char* val ) {
  iOAttr __Attr = allocMem( sizeof( struct OAttr ) );
  iOAttrData data = allocMem( sizeof( struct OAttrData ) );
  MemOp.basecpy( __Attr, &AttrOp, 0, sizeof( struct OAttr ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Attr;
}


/** Creates an attribute with given name and integer value. */
static struct OAttr* _instInt( const char* name ,int val ) {
  return 0;
}


/** Change attribute value. */
static void _setBoolean( struct OAttr* inst ,Boolean val ) {
  return;
}


/** Change attribute value. */
static void _setFloat( struct OAttr* inst ,double val ) {
  return;
}


/** Change attribute value. */
static void _setInt( struct OAttr* inst ,int val ) {
  return;
}


/** Change attribute value. */
static void _setLong( struct OAttr* inst ,long val ) {
  return;
}


/** Change attribute name. */
static void _setName( struct OAttr* inst ,const char* name ) {
  return;
}


/** Change attribute value. */
static void _setVal( struct OAttr* inst ,const char* val ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/attr.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
