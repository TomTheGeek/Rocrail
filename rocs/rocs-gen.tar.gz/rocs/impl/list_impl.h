/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Dec 24 2009 16:25:24)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Dec 25 22:06:04 2009
  */

#include "rocs/public/list.h"


static const char* name = "OList";

/* Initial listsize. */
#define LIST_MINSIZE 20
typedef struct OListData {

    /** List items. */
  obj* objList;
    /** Item pointer for next function. */
  int ix;
    /** Number of items in list. */
  int size;
    /** List size. */
  int allocsize;

} *iOListData;

static iOListData Data( void* p ) { return (iOListData)((iOList)p)->base.data; }

