/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jun 11 2009 07:08:17)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: Ebcdic
  * Date: Thu Jun 11 07:13:20 2009
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/ebcdic_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOEbcdicData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OEbcdic ----- */


/** Converts ascii into ebcdic. */
static char* _Ascii2Ebcdic( struct OEbcdic* inst ,char* ascii ,int count ) {
  return 0;
}


/** Converts ebcdic into ascii. */
static char* _Ebcdic2Ascii( struct OEbcdic* inst ,char* ebcdic ,int count ) {
  return 0;
}


/** Converts ebcdic into ascii. */
static char* _Ebcdic2ExtAscii( struct OEbcdic* inst ,char* ebcdic ,int count ) {
  return 0;
}


/** Converts ebcdic into ascii. */
static char* _Ebcdic2TrueAscii( struct OEbcdic* inst ,char* ebcdic ,int count ) {
  return 0;
}


/** Gets the ascii coding for the given ebcdic code. */
static char _getAscii( struct OEbcdic* inst ,char ebcdic ) {
  return 0;
}


/** Gets the ebcdic coding for the given ascii code. */
static char _getEbcdic( struct OEbcdic* inst ,char ascii ) {
  return 0;
}


/** Object creator. */
static struct OEbcdic* _inst( codepage CodePage ,const char* converterfile ) {
  iOEbcdic __Ebcdic = allocMem( sizeof( struct OEbcdic ) );
  iOEbcdicData data = allocMem( sizeof( struct OEbcdicData ) );
  MemOp.basecpy( __Ebcdic, &EbcdicOp, 0, sizeof( struct OEbcdic ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __Ebcdic;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/ebcdic.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
