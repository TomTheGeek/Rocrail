/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Jan 18 2011 17:59:59)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: CmdLn
  * Date: Tue Jan 18 18:08:33 2011
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/cmdln_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOCmdLnData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OCmdLn ----- */


/** Get an integer value by key. Returns given default value if not found. */
static int _getIntDef( struct OCmdLn* inst ,const char* key ,int defval ) {
  return 0;
}


/** Get a string value by key. */
static const char* _getStr( struct OCmdLn* inst ,const char* key ) {
  return 0;
}


/** Get a string value by key. Returns given default value if not found. */
static const char* _getStrDef( struct OCmdLn* inst ,const char* key ,const char* defval ) {
  return 0;
}


/** Test if the given key was on the commandline. */
static Boolean _hasKey( struct OCmdLn* inst ,const char* key ) {
  return 0;
}


/** Creates a commandline object. */
static struct OCmdLn* _inst( int argc ,const char** argv ) {
  iOCmdLn __CmdLn = allocMem( sizeof( struct OCmdLn ) );
  iOCmdLnData data = allocMem( sizeof( struct OCmdLnData ) );
  MemOp.basecpy( __CmdLn, &CmdLnOp, 0, sizeof( struct OCmdLn ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __CmdLn;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/cmdln.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
