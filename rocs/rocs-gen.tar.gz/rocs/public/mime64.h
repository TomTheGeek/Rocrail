/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar  5 2010 07:43:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Mar  7 09:50:22 2010
  */

#ifndef __object_Mime64_H
#define __object_Mime64_H

#include "rocs/public/rocs.h"
#include "rocs/public/objbase.h"

#ifdef __cplusplus
  extern "C" {
#endif





typedef struct OMime64 {
  /***** Base *****/
  struct OBase  base;

  /***** Object: Mime64 *****/
  /** decode the input file into it's  */
  Boolean (*decode)( const char* infile ,const char* outfile );
  /** encode the input file into mime64 */
  Boolean (*encode)( const char* infile ,const char* outfile );
} *iOMime64;

extern struct OMime64 Mime64Op;

#ifdef __cplusplus
  }
#endif


#endif
