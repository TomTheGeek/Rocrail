/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Mar  5 2010 07:43:48)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Mar  7 09:50:22 2010
  */

#ifndef __object_JS_H
#define __object_JS_H

#include "rocs/public/rocs.h"
#include "rocs/public/objbase.h"

/* Rocs includes: */
#include "rocs/public/list.h"
#include "rocs/public/thread.h"

#ifdef __cplusplus
  extern "C" {
#endif


typedef void(*jsListener )( int dev, int type, int number, int value, unsigned long msec );



typedef struct OJS {
  /***** Base *****/
  struct OBase  base;

  /***** Object: JS *****/
  /**  */
  int (*init)( struct OJS* inst ,int* devicemap );
  /** Object creator. */
  struct OJS* (*inst)( void );
  /** Set an JS listener. */
  Boolean (*setListener)( struct OJS* inst ,jsListener listener ,int devnr );
  /**  */
  void (*start)( struct OJS* inst );
} *iOJS;

extern struct OJS JSOp;

#ifdef __cplusplus
  }
#endif


#endif
