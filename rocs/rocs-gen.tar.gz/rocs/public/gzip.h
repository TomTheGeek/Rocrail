/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Sep 22 2010 19:49:45)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Fri Sep 24 12:13:16 2010
  */

#ifndef __object_GZip_H
#define __object_GZip_H

#include "rocs/public/rocs.h"
#include "rocs/public/objbase.h"

#ifdef __cplusplus
  extern "C" {
#endif





typedef struct OGZip {
  /***** Base *****/
  struct OBase  base;

  /***** Object: GZip *****/
  /**  */
  Boolean (*compress)( struct OGZip* inst );
  /**  */
  Boolean (*deCompress)( struct OGZip* inst );
  /**  */
  int (*getRc)( struct OGZip* inst );
  /** Object creator. */
  struct OGZip* (*inst)( const char* fileName );
} *iOGZip;

extern struct OGZip GZipOp;

#ifdef __cplusplus
  }
#endif


#endif
