/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Apr 22 2013 08:31:05)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Mon Apr 22 08:31:16 2013
  */

#ifndef __object_StrTok_H
#define __object_StrTok_H

#include "rocs/public/rocs.h"
#include "rocs/public/objbase.h"

/* Rocs includes: */
#include "rocs/public/str.h"

#ifdef __cplusplus
  extern "C" {
#endif





typedef struct OStrTok {
  /***** Base *****/
  struct OBase  base;

  /***** Object: StrTok *****/
  /** Get number of tokens. */
  int (*countTokens)( struct OStrTok* inst );
  /** There are more tokens left to read. */
  Boolean (*hasMoreTokens)( struct OStrTok* inst );
  /** Object creator. */
  struct OStrTok* (*inst)( const char* str ,char sep );
  /** A token. */
  const char* (*nextToken)( struct OStrTok* inst );
} *iOStrTok;

extern struct OStrTok StrTokOp;

#ifdef __cplusplus
  }
#endif


#endif
