/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jan 13 2009 19:55:50)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Jan 15 22:28:09 2009
  */

#ifndef __object_Mime64_H
#define __object_Mime64_H

#include "rocs/public/rocs.h"
#include "rocs/public/objbase.h"

#ifdef __cplusplus
  extern "C" {
#endif





typedef struct OMime64 {
  /***** Base *****/
  struct OBase  base;

  /***** Object: Mime64 *****/
  /** decode the input file into it's  */
  Boolean (*decode)( const char* infile ,const char* outfile );
  /** encode the input file into mime64 */
  Boolean (*encode)( const char* infile ,const char* outfile );
} *iOMime64;

extern struct OMime64 Mime64Op;

#ifdef __cplusplus
  }
#endif


#endif
