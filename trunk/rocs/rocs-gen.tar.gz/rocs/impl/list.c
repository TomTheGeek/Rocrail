/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D  (First time only!)
  * Generator: Rocs ogen (build Nov 26 2008 16:09:40)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Object: List
  * Date: Thu Dec 18 22:00:05 2008
  * ------------------------------------------------------------
  * $Source$
  * $Author$
  * $Date$
  * $Revision$
  * $Name$
  */

#include "rocs/impl/list_impl.h"

#include "rocs/public/mem.h"

static int instCnt = 0;

/** ----- OBase ----- */
static void __del( void* inst ) {
  if( inst != NULL ) {
    iOListData data = Data(inst);
    /* Cleanup data->xxx members...*/
    
    freeMem( data );
    freeMem( inst );
    instCnt--;
  }
  return;
}

static const char* __name( void ) {
  return name;
}

static unsigned char* __serialize( void* inst, long* size ) {
  return NULL;
}

static void __deserialize( void* inst,unsigned char* bytestream ) {
  return;
}

static char* __toString( void* inst ) {
  return NULL;
}

static int __count( void ) {
  return instCnt;
}

static struct OBase* __clone( void* inst ) {
  return NULL;
}

static Boolean __equals( void* inst1, void* inst2 ) {
  return False;
}

static void* __properties( void* inst ) {
  return NULL;
}

static const char* __id( void* inst ) {
  return NULL;
}

static void* __event( void* inst, const void* evt ) {
  return NULL;
}

/** ----- OList ----- */


/** Adds an object to the list. */
static void _add( struct OList* inst ,obj object ) {
  return;
}


/** Empties the list. */
static void _clear( struct OList* inst ) {
  return;
}


/** Gets the first object from the list. */
static obj _first( struct OList* inst ) {
  return 0;
}


/** Gets an object from the list by position. */
static obj _get( struct OList* inst ,int pos ) {
  return 0;
}


/** Gets the current pointer position. */
static int _getIndex( struct OList* inst ) {
  return 0;
}


/** Inserts an object into the list. */
static void _insert( struct OList* inst ,int pos ,obj object ) {
  return;
}


/** Object creator. */
static struct OList* _inst( void ) {
  iOList __List = allocMem( sizeof( struct OList ) );
  iOListData data = allocMem( sizeof( struct OListData ) );
  MemOp.basecpy( __List, &ListOp, 0, sizeof( struct OList ), data );

  /* Initialize data->xxx members... */

  instCnt++;
  return __List;
}


/** Gets the next object from the list. */
static obj _next( struct OList* inst ) {
  return 0;
}


/** Removes an object from the list by position. */
static obj _remove( struct OList* inst ,int pos ) {
  return 0;
}


/** Removes an object from the list by reference. */
static obj _removeObj( struct OList* inst ,obj object ) {
  return 0;
}


/** Replaces an object. */
static void _replace( struct OList* inst ,int pos ,obj object ) {
  return;
}


/** Gets the number of objects currently in the list. */
static int _size( struct OList* inst ) {
  return 0;
}


/** Sorts this list. */
static void _sort( struct OList* inst ,comparator comp ) {
  return;
}


/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
#include "rocs/impl/list.fm"
/* ----- DO NOT REMOVE OR EDIT THIS INCLUDE LINE! -----*/
